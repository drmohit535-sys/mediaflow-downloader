const MAX_BYTES = 100 * 1024 * 1024;
const allowedTypes = new Set([
  "video/mp4","video/webm",
  "audio/mpeg","audio/mp4","audio/wav","audio/x-wav","audio/ogg","audio/webm",
  "image/jpeg","image/png","image/webp","image/gif"
]);
const extensions = {
  "video/mp4":"mp4","video/webm":"webm","audio/mpeg":"mp3",
  "audio/mp4":"m4a","audio/wav":"wav","audio/x-wav":"wav",
  "audio/ogg":"ogg","audio/webm":"webm","image/jpeg":"jpg",
  "image/png":"png","image/webp":"webp","image/gif":"gif"
};
const $ = id => document.getElementById(id);
$("year").textContent = new Date().getFullYear();

function setStatus(message, kind="error") {
  const el = $("status");
  el.hidden = false;
  el.className = "status " + kind;
  el.textContent = message;
}
function validPublicHttpsUrl(value) {
  const u = new URL(value);
  if (u.protocol !== "https:" || u.username || u.password) throw new Error("Use a public HTTPS URL without embedded credentials.");
  const h = u.hostname.toLowerCase().replace(/\\.$/, "");
  if (!h || h === "localhost" || h.endsWith(".localhost") || h.endsWith(".local") ||
      h === "127.0.0.1" || h === "::1" || h === "0.0.0.0" ||
      /^10\\./.test(h) || /^192\\.168\\./.test(h) ||
      /^172\\.(1[6-9]|2\\d|3[01])\\./.test(h) || /^169\\.254\\./.test(h)) {
    throw new Error("Private or local network addresses are not allowed.");
  }
  return u;
}
function safeFilenameFromUrl(url, extension) {
  let name = "";
  try { name = decodeURIComponent(url.pathname.split("/").pop() || "media"); } catch {}
  name = name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 70);
  if (!name || name === "." || name === "..") name = "media";
  name = name.replace(/\\.[a-zA-Z0-9]{1,8}$/, "");
  return name + "." + extension;
}
function saveHistory(name, size, type) {
  let history = [];
  try { history = JSON.parse(localStorage.getItem("mediaflow-history") || "[]"); } catch {}
  history.unshift({name, size, type, date: new Date().toLocaleString()});
  localStorage.setItem("mediaflow-history", JSON.stringify(history.slice(0, 10)));
  renderHistory();
}
function renderHistory() {
  let history = [];
  try { history = JSON.parse(localStorage.getItem("mediaflow-history") || "[]"); } catch {}
  const box = $("historyList");
  box.replaceChildren();
  if (!history.length) {
    const p = document.createElement("p");
    p.className = "empty";
    p.textContent = "Your successful direct downloads will appear here.";
    box.append(p);
    return;
  }
  history.forEach(item => {
    const row = document.createElement("div");
    row.className = "history-item";
    const name = document.createElement("strong");
    name.textContent = item.name;
    const detail = document.createElement("span");
    detail.textContent = `${item.type} · ${item.size} · ${item.date}`;
    row.append(name, detail);
    box.append(row);
  });
}
$("clearHistory").addEventListener("click", () => {
  localStorage.removeItem("mediaflow-history");
  renderHistory();
});
renderHistory();

async function downloadMedia() {
  const button = $("downloadBtn");
  const raw = $("mediaUrl").value.trim();
  $("status").hidden = true;
  $("progressWrap").hidden = true;
  $("progressBar").style.width = "0%";
  if (!raw) return setStatus("Paste a direct media-file URL first.");

  let url;
  try { url = validPublicHttpsUrl(raw); }
  catch (e) { return setStatus(e.message || "Enter a valid HTTPS URL."); }

  button.disabled = true;
  button.textContent = "Checking file…";
  $("progressWrap").hidden = false;
  $("progressLabel").textContent = "Connecting to the source…";

  try {
    // Browser-only fetch: the source must permit cross-origin access (CORS).
    const response = await fetch(url.href, {method:"GET", mode:"cors", credentials:"omit"});
    if (!response.ok) throw new Error(`The source returned HTTP ${response.status}.`);
    const type = (response.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
    if (!allowedTypes.has(type)) throw new Error("Unsupported file type. Use a direct MP4, WebM, audio or image file URL.");

    const declaredSize = Number(response.headers.get("content-length") || 0);
    if (declaredSize > MAX_BYTES) throw new Error("This tool supports files up to 100 MB.");

    let blob;
    if (response.body && response.body.getReader) {
      const reader = response.body.getReader();
      const chunks = [];
      let received = 0;
      while (true) {
        const {done, value} = await reader.read();
        if (done) break;
        received += value.byteLength;
        if (received > MAX_BYTES) {
          await reader.cancel();
          throw new Error("The file exceeds the 100 MB limit.");
        }
        chunks.push(value);
        if (declaredSize > 0) {
          const pct = Math.min(99, Math.round(received / declaredSize * 100));
          $("progressBar").style.width = pct + "%";
          $("progressLabel").textContent = `Downloading… ${pct}%`;
        } else {
          $("progressLabel").textContent = `Downloaded ${(received / 1048576).toFixed(1)} MB…`;
        }
      }
      blob = new Blob(chunks, {type});
    } else {
      blob = await response.blob();
      if (blob.size > MAX_BYTES) throw new Error("The file exceeds the 100 MB limit.");
    }
    if (!blob.size) throw new Error("The source returned an empty file.");

    const filename = safeFilenameFromUrl(url, extensions[type]);
    const objectUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = objectUrl;
    a.download = filename;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);

    $("progressBar").style.width = "100%";
    $("progressLabel").textContent = "Download handed to your browser.";
    setStatus(`Download started: ${filename} (${(blob.size / 1048576).toFixed(2)} MB)`, "ok");
    saveHistory(filename, (blob.size / 1048576).toFixed(2) + " MB", type);
  } catch (e) {
    let message = e.message || "Download failed.";
    if (e instanceof TypeError) message = "The source blocked browser access (often CORS), or the network request failed. Try the source’s official download option.";
    setStatus(message);
    $("progressLabel").textContent = "Download could not be completed.";
  } finally {
    button.disabled = false;
    button.innerHTML = 'Download file <span>↓</span>';
  }
}
$("downloadBtn").addEventListener("click", downloadMedia);
$("mediaUrl").addEventListener("keydown", e => { if (e.key === "Enter") downloadMedia(); });
