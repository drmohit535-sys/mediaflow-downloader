# MediaFlow — Personal Media Hub

A free, static GitHub Pages project for personal use.

## What it does
- Opens official export/download tools for your own YouTube, Facebook and Instagram content.
- Downloads direct HTTPS media-file URLs when the source allows browser cross-origin access (CORS).
- Supports selected video, audio and image MIME types up to 100 MB.
- Stores a small list of successful direct-download filenames in this browser's local storage.

## What it does not do
- It does not extract video streams from YouTube, Facebook or Instagram post URLs.
- It does not bypass DRM, login restrictions, access controls or platform download restrictions.
- It does not ask for social-media passwords.
- It has no backend, API key, proxy or server-side downloader.

## Publish on GitHub Pages
1. Create a **public** GitHub repository named `mediaflow-personal`.
2. Upload all files in this folder to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose branch `main`, folder `/(root)`, then Save.
6. Wait for the Pages deployment. The site URL will look like:
   `https://YOUR-USERNAME.github.io/mediaflow-personal/`

## Test
Use a direct HTTPS link to a media file that you own or are allowed to download. The host must send suitable CORS headers. A normal social-media post URL is not a direct media-file URL and will not work.

## Privacy
Download history is stored locally in this browser. Clear it with the **Clear history** button. The direct-file URL is not stored by this app.
